--[모델링 과제] 스크립트 파일명 : 본인이름_모델링.sql
--외래키가 존재하는 테이블 모델링 연습
--1. 동물병원의 반려동물, 보호자의 정보를 저장하고 관리한다
--2. 보호자는 번호, 이름, 주소, 핸드폰 번호, 이메일주소를 가진다
--3. 반려동물은 번호, 이름, 성별, 나이, 종, 품종, 보호자 번호를 가진다
--4. 모든 보호자는 중복이 없는 번호를 가진다
--5. 보호자의 이름, 주소, 핸드폰 번호는 필수 정보이다
--6. 모든 동물은 중복이 없는 번호를 가진다
--7. 동물의 이름, 성별, 나이, 종, 보호자 번호는 필수 정보이다
--8. 동물의 보호자 번호는 실제 존재하는 보호자 번호여야 한다
--
--- 요구사항 분석
-- 동물병원 케어하고 있는 반려동물과 반려동물의 보호자 2가지 데이터를 관리하고자 한다.

--- 개념적 설계
-- 보호자     / 반려동물
-- 번호      / 번호
-- 이름   	/ 이름
-- 주소 	    / 성별
-- 핸드폰번호 / 나이
-- 이메일주소 / 품종
--          / 보호자번호


--- 논리적 설계
-- 보호자     		/ 반려동물
-- 번호(PK)(UK)		/ 번호(PK)(UK)
-- 이름(NOT NULL)   	/ 이름(NOT NULL)
-- 주소(NOT NULL) 	 / 성별(NOT NULL)
-- 핸드폰번호(NOT NULL) / 나이(NOT NULL)
-- 이메일주소 			/ 품종(NOT NULL)
--          		/ 보호자번호(FK)(NOT NULL)



--- 물리적 설계
/* 보호자
 * 	TBL_OWNER2
	OWNER_NUMBER : VARCHAR2(500) : PRIMARY KEY
	----------------------------------------
	OWNER_NAME : VARCHAR2(500)
	OWNER_ADDRESS : VARCHAR2(500)
	OWNER_EMAIL : VARCHAR2(500)
	OWNER_PHONE_NUMBER : VARCHAR2(500)
 */

/* 반려동물
 * 	TBL_ANIMAL2
	ANIMAL_NUMBER : VARCHAR2(500) : PRIMARY KEY
	---------------------------------------------------
	ANIMAL_NAME : VARCHAR2(500)
	ANIMAL_SEX : VARCHAR2(500)
	ANIMAL_AGE : NUMBER
	ANIMAL_BREED : VARCHAR2(500)
	OWNER_NO : NUMBER : FOREIGN KEY

 */

--- 구현 쿼리문(각 5개씩 추가까지하기) 엔티티 관계도 화면 캡처
CREATE TABLE TBL_OWNER2(
    OWNER_NO  VARCHAR2(500),
    OWNER_NAME  VARCHAR2(500) NOT NULL,
    OWNER_ADDRESS VARCHAR2(500) NOT NULL,
    OWNER_EMAIL VARCHAR2(500),
    OWNER_PHONE_NUMBER VARCHAR2(500) NOT NULL,
    CONSTRAINT PK_OWNER2 PRIMARY KEY(OWNER_NO)
);


CREATE TABLE TBL_ANIMAL2(
	ANIMAL_NUMBER VARCHAR2(500),
	ANIMAL_NAME VARCHAR2(500) NOT NULL,
	ANIMAL_SEX VARCHAR2(500) NOT NULL,
	ANIMAL_AGE NUMBER NOT NULL,
	ANIMAL_BREED VARCHAR2(500) NOT NULL,
	OWNER_NO VARCHAR2(500) NOT NULL,
	CONSTRAINTS PK_ANIMAL2 PRIMARY KEY(ANIMAL_NUMBER),
	CONSTRAINTS FK_ANIMAL2 FOREIGN KEY(OWNER_NO)
	REFERENCES TBL_OWNER2(OWNER_NO)
);
--구현테이블 확인
SELECT * FROM TBL_OWNER2;
SELECT * FROM TBL_ANIMAL2;

--구현테이블에 데이터 추가
INSERT INTO TBL_OWNER2
(OWNER_NO, OWNER_NAME, OWNER_ADDRESS, OWNER_EMAIL, OWNER_PHONE_NUMBER)
VALUES('1', '김민수', '서울', 'KMS@NAVER.COM', '010-1111-1111');
INSERT INTO TBL_OWNER2
(OWNER_NO, OWNER_NAME, OWNER_ADDRESS, OWNER_EMAIL, OWNER_PHONE_NUMBER)
VALUES('2', '강호동', '서울', 'KHD@NAVER.COM', '010-1112-1112');
INSERT INTO TBL_OWNER2
(OWNER_NO, OWNER_NAME, OWNER_ADDRESS, OWNER_EMAIL, OWNER_PHONE_NUMBER)
VALUES('3', '유재석', '서울', 'YJS@NAVER.COM', '010-1113-1113');
INSERT INTO TBL_OWNER2
(OWNER_NO, OWNER_NAME, OWNER_ADDRESS, OWNER_EMAIL, OWNER_PHONE_NUMBER)
VALUES('4', '하하', '서울', 'HH@NAVER.COM', '010-1114-1114');
INSERT INTO TBL_OWNER2
(OWNER_NO, OWNER_NAME, OWNER_ADDRESS, OWNER_EMAIL, OWNER_PHONE_NUMBER)
VALUES('5', '이상혁', '서울', 'LSH@NAVER.COM', '010-1115-1115');


INSERT INTO TBL_ANIMAL2
(ANIMAL_NUMBER, ANIMAL_NAME, ANIMAL_SEX, ANIMAL_AGE, ANIMAL_BREED, OWNER_NO)
VALUES('1','진돌이','MALE', '1', '진돗개', '1');
INSERT INTO TBL_ANIMAL2
(ANIMAL_NUMBER, ANIMAL_NAME, ANIMAL_SEX, ANIMAL_AGE, ANIMAL_BREED, OWNER_NO)
VALUES('2','찹쌀떡','FEMALE', '2', '포메리안', '2');
INSERT INTO TBL_ANIMAL2
(ANIMAL_NUMBER, ANIMAL_NAME, ANIMAL_SEX, ANIMAL_AGE, ANIMAL_BREED, OWNER_NO)
VALUES('3','먼지','FEMALE', '3', '러시안블루', '3');
INSERT INTO TBL_ANIMAL2
(ANIMAL_NUMBER, ANIMAL_NAME, ANIMAL_SEX, ANIMAL_AGE, ANIMAL_BREED, OWNER_NO)
VALUES('4','사자','MALE', '4', '브리티시숏헤어', '4');
INSERT INTO TBL_ANIMAL2
(ANIMAL_NUMBER, ANIMAL_NAME, ANIMAL_SEX, ANIMAL_AGE, ANIMAL_BREED, OWNER_NO)
VALUES('5','짬타이거','MALE', '5', '코리안숏헤어', '5');